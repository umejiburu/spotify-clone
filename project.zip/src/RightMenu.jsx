import React from 'react'

function RightMenu() {
  return (
    <div className='rightMenu'></div>
  )
}

export  {RightMenu}
import React from 'react'

function RightContainer() {
  return (
    <div>RightContaine</div>
  )
}

export default RightContainer
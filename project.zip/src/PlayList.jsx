const PlayList = [
  {id: 1, name: 'Top hit 2021'},
  {id: 2, name: 'Dance'},
  {id: 3, name: 'Relaxing Music'},
  {id: 4, name: 'Instrumental'},
  {id: 5, name: 'Hip Pop'},
  {id: 6, name: 'Workout Music'}
]

export {PlayList}
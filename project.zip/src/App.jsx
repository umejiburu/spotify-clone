import { useState } from 'react'
import { MainContainer } from './MainContainer'
import { LeftMenu } from './LeftMenu'
import { RightMenu } from './RightMenu'


function App() {
  const [count, setCount] = useState(0)

  return (
    <div className="App">
        <LeftMenu/>
        <MainContainer/>
        <RightMenu/>

        <div className='background'></div>
    </div>
  )
}

export default App
